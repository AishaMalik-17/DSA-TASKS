#include<iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
    Node* prev;
};

void add(Node*& head, int val){
    Node* newNode = new Node();
    newNode->data = val;
    newNode->next = NULL;
    newNode->prev = NULL;

    if(head == NULL){
        head = newNode;
        return;
    }

    Node* temp = head;
    while(temp->next != NULL){
        temp = temp->next;
    }
    temp->next = newNode;
    newNode->prev = temp;
}

double total(Node* head){
    int sum = 0;
    Node* temp = head;
    while(temp != NULL) {
        sum += temp->data;
        temp = temp->next;
    }
    return sum;
}

double average(Node* head){
    return total(head)/7.0;
}

void rainfallAfter5(Node* head){
    Node* temp = head;
    int count = 1;

    while(temp != NULL && count < 6){
        temp = temp->next;
        count++;
    }

    if(temp != NULL){
        cout << "Rainfall on Day 6 = "<< temp->data<<" mm"<<endl;
    } 
	else{
        cout<<"There is no day after the 5th node."<<endl;
    }
}

void findMaxMin(Node* head) {
    if (head == NULL) {
        cout << "List is empty!" << endl;
        return;
    }

    Node* temp = head;
    int day = 1;
    int maxRain = temp->data, minRain = temp->data;
    int dayMax = 1, dayMin = 1;

    while (temp != NULL) {
        if(temp->data > maxRain){
            maxRain = temp->data;
            dayMax = day;
        }
        if(temp->data < minRain){
            minRain = temp->data;
            dayMin = day;
        }
        temp = temp->next;
        day++;
    }

    cout<<"Highest Rainfall : "<<maxRain<<" mm on Day "<<dayMax<<endl;
    cout<<"Lowest Rainfall : "<<minRain<<" mm on Day "<<dayMin<<endl;
}

int main() {
    Node* head = NULL;
    int rainfall;

    cout<<"Enter rainfall for 7 days:"<<endl;
    for(int i=1; i<=7; i++){
        do {
            cout<<"Day "<<i<<": ";
            cin>>rainfall;

            if(rainfall < 0){
                cout<<"Rainfall cannot be negative. Enter again."<<endl;
            }
        } 
		while (rainfall < 0);
        add(head, rainfall);
    }

    cout << "\nRainfall Data (Doubly Linked List):" << endl;

    cout << "\nTotal Rainfall = " << total(head) << endl;
    cout << "Average Rainfall = " << average(head) << endl;
    
    findMaxMin(head);
	rainfallAfter5(head);
    return 0;
}

