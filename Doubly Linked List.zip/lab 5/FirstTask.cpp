#include<iostream>
using namespace std;

struct Nodes{
	int data;
	Nodes* next;
	Nodes* prev;
};

void display(Nodes* head){
	if(head == NULL){
		cout<<"NULL";
		return;
	}
	Nodes* temp = head;
	while(temp != NULL){
		cout<<temp->data<<" ";
		temp = temp->next;
	}
	cout<<endl;
}

void add(Nodes*& head, int marks){
	Nodes* newNode = new Nodes();
	newNode->data = marks;
	newNode->next = NULL;
	newNode->prev = NULL;
	
	if(head == NULL){
		head = newNode;
		newNode->prev = NULL;
		return;
	}
	
	Nodes* temp = head;
	while(temp->next != NULL){
		temp = temp->next;
	}
	temp->next = newNode;
	newNode->prev = temp;
}

void atBeg(Nodes*& head, int marks){
	Nodes* newNode = new Nodes();
	cout<<"Enter marks: ";
	cin>>marks;
	newNode->data = marks;
	newNode->prev = NULL;
	newNode->next = head;
	
	if(head != NULL){
		head->prev = newNode;  
	}
	
	head = newNode;
	cout<<"Added Successfully."<<endl;
}

void deleteAtBeginning(Nodes*& head){
    if(head == NULL){
        cout<<"List is empty. Nothing to delete."<<endl;
        return;
    }

    Nodes* temp = head;       
    head = head->next;     

    if(head != NULL){
        head->prev = NULL; 
    }

    cout<<"\nDeleting "<<temp->data<<endl;
    delete temp;
    cout<<"Deleted Successfully."<<endl;
}

void specific(Nodes*& head, int marks){
    cout<<"Enter marks: ";
    cin>>marks;

    if(head == NULL){
        cout<<"\nList is empty."<<endl;
        return;
    }

    Nodes* temp = head;    
    while(temp != NULL && temp->data != 45){
        temp = temp->next;
    }

    if(temp == NULL){
        cout<<"\nValue 45 not found in the list."<<endl;
        return;
    }

    Nodes* newNode = new Nodes();
    newNode->data = marks;

    newNode->next = temp->next;
    newNode->prev = temp;

    if(temp->next != NULL){
        temp->next->prev = newNode;
    }

    temp->next = newNode;

    cout<<"Added Successfully."<<endl;
}

void deleteSpecific(Nodes*& head){
    if(head == NULL){
        cout<<"\nList is empty. Nothing to delete."<<endl;
        return;
    }

    Nodes* temp = head;    
    while (temp != NULL && temp->data != 45) {
        temp = temp->next;
    }

    if(temp == NULL){
        cout<<"Value 45 not found in the list."<<endl;
        return;
    }

    if(temp->next == NULL){
        cout<<"\nNo node exists after 45, so deletion not possible."<<endl;
        return;
    }

    Nodes* nodeToDelete = temp->next;
    temp->next = nodeToDelete->next;

    if(nodeToDelete->next != NULL){
        nodeToDelete->next->prev = temp;
    }

    cout<<"\nDeleting "<<nodeToDelete->data<<endl;
    delete nodeToDelete;
    cout<<"Deleted Successfully."<<endl;
}


int main(){
	Nodes* nodes = NULL;
	int size,mark,choice;
	cout<<"How many nodes you want to create: ";
	cin>>size;
	cout<<endl;
	
	for(int i=0; i<size; i++){
		cout<<"Enter marks for "<<i+1<<" node: ";
		cin>>mark;
		add(nodes,mark);
	}
	
	cout<<"\nList is "<<endl;
	display(nodes);
	
	cout<<"\n****MENU****"<<endl;
	
	do{
		cout<<"\n1. Insertion at beginning."<<endl;
		cout<<"2. Insertion after 45 marks."<<endl;
		cout<<"3. Deletion at beginning."<<endl;
		cout<<"4. Deletion after 45 marks."<<endl;
		cout<<"5. Exit."<<endl<<endl;
		
		cout<<"Choose from the above options: ";
		cin>>choice;
		
		switch(choice){
			case 1:
				atBeg(nodes,mark);
				break;
				
			case 2:
				specific(nodes,mark);
				break;
				
			case 3:
				deleteAtBeginning(nodes);
				break;
				
			case 4:
				deleteSpecific(nodes);
				break;
			
			case 5:
				cout<<"Exiting....."<<endl;
				cout<<"Final list is: "<<endl;
				display(nodes);
				break;
			
			default:
				cout<<"Invalid Option....\\Choose the correct option.";				
		}
	}
	while(choice != 5);
	return 0;
}
