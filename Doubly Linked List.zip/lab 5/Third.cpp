#include<iostream>
using namespace std;
struct Player {
    string name;
    int score;
    Player* next;
    Player* prev;
};

Player* head = NULL;

void addPlayer(string name, int score){
    Player* newNode = new Player();
    newNode->name = name;
    newNode->score = score;
    newNode->next = NULL;
    newNode->prev = NULL;

    if(head == NULL){  
        head = newNode;
        return;
    }

    Player* temp = head;
    
    if(score < temp->score){
        newNode->next = head;
        head->prev = newNode;
        head = newNode;
        return;
    }

    while(temp->next != NULL && temp->next->score < score){
        temp = temp->next;
    }

    newNode->next = temp->next;
    if(temp->next != NULL){
        temp->next->prev = newNode;
    }
    temp->next = newNode;
    newNode->prev = temp;
}

void deletePlayer(string name) {
    if (head == NULL) {
        cout << "List is empty.\n";
        return;
    }

    Player* temp = head;
    while(temp != NULL && temp->name != name){
        temp = temp->next;
    }

    if(temp == NULL){
        cout << "Player not found.\n";
        return;
    }

    if(temp->prev != NULL){
        temp->prev->next = temp->next;
    } 
	else{
        head = temp->next; 
    }

    if(temp->next != NULL){
        temp->next->prev = temp->prev;
    }

    cout<<"Deleting Player: "<<temp->name<<" ("<<temp->score<<")\n";
    delete temp;
}

void displayAll(){
    Player* temp = head;
    
    if(temp == NULL){
        cout<<"List is empty.\n";
        return;
    }
    cout<<"\nPlayers (Ascending by Score):\n";
    
    while(temp != NULL){
        cout<<temp->name<<" ("<<temp->score<<")\n";
        temp = temp->next;
    }
}

void displayLowest(){
	
    if(head == NULL){
        cout<<"List is empty.\n";
        return;
    }
    cout<<"Lowest Score Player: "<<head->name<<" ("<<head->score<<")\n";
}

void displaySameScore(int score){
	
    Player* temp = head;
    bool found = false;
    cout<<"Players with score "<<score<<":\n";
    
    while(temp != NULL){
        if(temp->score == score){
            cout<<temp->name<<" ("<<temp->score<<")\n";
            found = true;
        }
        temp = temp->next;
    }
    if(!found){
        cout<<"No players found with score "<<score<<endl;
    }
}

void displayBackward(string name){
	
    Player* temp = head;
    while(temp != NULL && temp->name != name){
        temp = temp->next;
    }

    if(temp == NULL){
        cout<<"Player not found.\n";
        return;
    }

    cout<<"Players backward from "<< name<< ":\n";
    
    while(temp != NULL){
        cout<<temp->name<<" (" << temp->score<<")\n";
        temp = temp->prev;
    }
}


int main() {
    int choice;
    string name;
    int score;
    cout<<"\n*** Golf Tournament Menu ***"<<endl;
        
    do{
        cout<<"\n1. Add Player (Sorted by Score)\n";
        cout<<"2. Delete Player by Name\n";
        cout<<"3. Display All Players\n";
        cout<<"4. Display Lowest Score Player\n";
        cout<<"5. Display Players with Same Score\n";
        cout<<"6. Display Backward from a Player\n";
        cout<<"7. Exit\n\n";
        cout<<"Enter choice: ";
        cin>>choice;
        cout<<endl;

        switch(choice){
        	
            case 1:
                cout<<"Enter name: ";
                cin>>name;
                cout<<"Enter score: ";
                cin>>score;
                addPlayer(name, score);
                break;
                
            case 2:
                cout<<"Enter name to delete: ";
                cin>>name;
                deletePlayer(name);
                break;
                
            case 3:
                displayAll();
                break;
                
            case 4:
                displayLowest();
                break;
                
            case 5:
                cout << "Enter score: ";
                cin >> score;
                displaySameScore(score);
                break;
                
            case 6:
                cout << "Enter player name: ";
                cin >> name;
                displayBackward(name);
                break;
                
            case 7:
                cout << "Exiting...\n";
                break;
                
            default:
                cout << "Invalid choice!\n";
        }
    } 
	while(choice != 7);
    return 0;
}
