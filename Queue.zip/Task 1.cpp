#include<iostream>
using namespace std;

struct Node{
	int application_id;
	float height;
	float weight;
	float eyesight;
	string status;
	Node* next;
	Node* prev;
};

class Queue{
	Node* front;
	Node* rare;
	
	public:
		Queue(){
			front = rare = NULL;
		}
		
		void enQueue(int id,float h,float w,float eye, string st){
			Node* newNode = new Node();
			newNode->application_id = id;
			newNode->height = h;
			newNode->weight = w;
			newNode->eyesight = eye;
			newNode->status = st;
			newNode->next = NULL;
			newNode->prev = NULL;
			
			if(rare == NULL){
				front = rare = newNode;
				cout<<"Added Successfully."<<endl<<endl;
				return;
			}
			rare->next = newNode;
			newNode->prev = rare;
			rare = newNode;
			cout<<"Added Successfully."<<endl<<endl;
		}
		
		void deQueue(){
			if(front==NULL){
				cout<<"Empty Stack."<<endl<<endl;
				return;
			}
			Node* del = front;
			front = front->next;
			
			cout<<"Applicant "<<del->application_id<<" is leaving."<<endl;
			
			if(front == NULL){
				rare = NULL;
			}
			else{
				front->prev = NULL;
			}
			delete del;
			cout<<"Deleted Successfully."<<endl<<endl;
		}
		
		void delete2nd(){
			if(front == NULL || front->next == NULL){
				cout<<"No 2nd element."<<endl<<endl;
				return;
			}
			Node* del = front->next;
			cout<<"Applicant "<<del->application_id<<" is leaving."<<endl;
			
			front->next = del->next;
			
			if(del->next != NULL){
				del->next->prev = front;
			}
			else{
				rare = front;
			}
			delete del;
			cout<<"Deleted Successfully."<<endl<<endl;
		}
		
		void display(){
			if(front==NULL){
				cout<<"Empty Stack."<<endl<<endl;
				return;
			}
			Node* temp = front;
			while(temp != NULL){
				cout<<"ID: "<<temp->application_id<<endl;
				cout<<"Heigt: "<<temp->height<<endl;
				cout<<"Weight: "<<temp->weight<<endl;
				cout<<"Eyesight: "<<temp->eyesight<<endl;
				cout<<"Status: "<<temp->status<<endl;
				cout<<endl<<endl;
				temp= temp->next;
			}
			cout<<endl;
		}
};

int main() {
    Queue queue;

    queue.enQueue(101, 5.8, 70, 6.0, "Pending");
    queue.enQueue(102, 5.6, 65, 6.2, "Pending");
    queue.enQueue(103, 5.7, 72, 5.8, "Pending");
    queue.enQueue(104, 6.0, 80, 6.5, "Pending");
    queue.enQueue(105, 5.9, 68, 6.0, "Pending");
    queue.enQueue(106, 6.1, 75, 6.3, "Pending");
    queue.enQueue(107, 5.5, 60, 5.9, "Pending");

    queue.display();

    queue.delete2nd();
    queue.display();

    queue.deQueue();
    queue.display();

    return 0;
}
