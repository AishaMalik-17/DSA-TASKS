#include<iostream>
using namespace std;
struct Node {
    int truck_id;
    Node* next;
    Node* prev;
};

class Queue{
    Node* front;
    Node* rear;

public:
    Queue(){
        front = rear = NULL;
    }

    bool isEmpty(){
        return front == NULL;
    }
    
    void enqueue(int id){
        Node* newNode = new Node();
        newNode->truck_id = id;
        newNode->next = NULL;

        if (rear == NULL){
            front = rear = newNode;
            cout<<"Truck "<<id<<" added on road successfully."<<endl;
            return;
        }

        rear->next = newNode;
        rear = newNode;
        cout<<"Truck "<< id<<" added on road successfully."<<endl;
    }
    
    void dequeue(){
        if (front == NULL){
            cout<<"Road is empty! No truck to move."<<endl;
            return;
        }

        Node* temp = front;
        front = front->next;

        if (front == NULL)
            rear = NULL;

        cout<<"Truck "<<temp->truck_id<<" moved from road."<<endl;
        delete temp;
    }
    
    void display(){
        if (front == NULL){
            cout << "No trucks on road.\n";
            return;
        }

        Node* temp = front;
        cout<<"Trucks on road: ";
        while (temp != NULL) {
            cout<<temp->truck_id<<" ";
            temp = temp->next;
        }
        cout<<endl<<endl;
    }
    
    int getFront(){
        if (isEmpty()){
            return -1;
     	}
        return front->truck_id;
    }
};

class Stack{
    Node* top;

public:
    Stack(){
        top = NULL;
    }

    bool isEmpty(){
        return top == NULL;
    }

    void push(int id){
        Node* newNode = new Node();
        newNode->truck_id = id;
        newNode->prev = top;
        top = newNode;
        cout<<"Truck "<<id<<" entered the garage."<<endl;
    }

    void pop() {
        if (isEmpty()) {
            cout<<"Garage is empty."<<endl;
            return;
        }
        cout<<"Truck "<<top->truck_id<<" exited the garage."<<endl;
        Node* temp = top;
        top = top->prev;
        delete temp;
    }

    int peek(){
        if (isEmpty()){
            return -1;
        }
        return top->truck_id;
    }

    void display(){
        if (isEmpty()){
            cout << "No trucks in garage." << endl;
            return;
        }
        cout<<"Trucks in Garage: ";
        Node* temp = top;
        while (temp != NULL) {
            cout<<temp->truck_id<<" ";
            temp = temp->prev;
        }
        cout<<endl<<endl;
    }
};

class TruckSystem{
    Queue road;
    Stack garage;

public:
    void On_road(int id){
        road.enqueue(id);
    }

    void Enter_garage(int id){
        if (road.isEmpty()){
            cout<<"No truck waiting on road."<<endl;
            return;
        }
        if (road.getFront() != id){
            cout<<"Truck "<<id <<" is not at the front of the road."<<endl;
            return;
        }
        road.dequeue();
        garage.push(id);
    }

    void Exit_garage(int id){
        if (garage.isEmpty()){
            cout<<"Garage is empty."<<endl;
            return;
        }
        if (garage.peek() == id){
            garage.pop();
      	}
        else{
            cout << "Truck is not near garage door."<<endl;
        }
    }

    void Show_trucks(string where){
        if (where == "road"){
            road.display();
     	}
        else if (where == "garage"){
            garage.display();
     	}
        else{
            cout << "Invalid choice."<<endl;
        }
    }
};

int main(){
    TruckSystem t;

    t.On_road(101);
    t.On_road(102);
    t.On_road(103);
    t.Show_trucks("road");

    t.Enter_garage(101);
    t.Enter_garage(102);
    t.Show_trucks("garage");

    t.Exit_garage(101);  
    t.Exit_garage(102);  
    t.Show_trucks("garage");

    return 0;
}

