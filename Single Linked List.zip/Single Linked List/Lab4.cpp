#include<iostream>
using namespace std;
struct Node{
	int data;
	Node* next;
};

void display(Node* head){
	Node* temp = head;
	while(temp!=NULL){
		cout<<temp->data<<" ";
		temp = temp->next;
	}
}

void atBeginning(Node*& head, int val){
	Node* newNode = new Node();
	newNode->data = val;
	newNode->next = head;
	head = newNode;
}

void atPosition(Node*& head, int val, int pos){
	Node* newNode = new Node();
	newNode->data = val;
	
	if(pos == 1){
		newNode->next = head;
		head = newNode;
		return;
	}
	
	Node* temp = head;
	int count = 1;
	
	while(count<pos-1 && temp!=NULL){
		temp = temp->next;
		count++;
	}
	
	if(temp == 	NULL){
		cout<<"Position not available."<<endl<<endl;
		delete newNode;
	}
	else{
		newNode->next = temp->next;
		temp->next = newNode;
	}
}

void atEnd(Node*& head, int val){
	Node* newNode = new Node();
	newNode->data = val;
	newNode->next = NULL;
	
	if(head == NULL){
		head = newNode;
	}
	else{
		Node* temp = head;
		while(temp->next != NULL){
			temp = temp->next;
		}
		temp->next = newNode;
	}
}
int main(){
	Node* head = NULL;
	int choice,num,p;
	cout<<"*****Welcome*****"<<endl;
	cout<<"Following is the Menu:\n";
	do{
		cout<<"\n1 is for insertion at the beginning."<<endl;
		cout<<"2 is for insertion at the specific position. "<<endl;
		cout<<"3 is for insertion at the end"<<endl;
		cout<<"4 is for Exit."<<endl<<endl;
		cout<<"Choose from the above menu: ";
		cin>>choice;
	
		switch(choice){
			case 1:
				cout<<"Enter value you want to add: ";
				cin>>num;
				atBeginning(head,num);
				break;
		
			case 2:
				cout<<"Enter value you want to add: ";
				cin>>num;
				cout<<"Enter position: ";
				cin>>p;
				atPosition(head,num,p);
				break;
		
			case 3: 
				cout<<"Enter value you want to add: ";
				cin>>num;
				atEnd(head,num);
				break;
		
			case 4:
				cout<<"Exiting the program."<<endl<<endl;
				cout<<"Final list is: ";
				display(head);
				break;
		
			default:
				cout<<"ERROR!!! Enter the correct option.";				
			}
		}
	while(choice != 4);
	
	return 0;
}
