#include<iostream>
using namespace	std;
struct Nodes{
	int data;
	Nodes* next;
};

void display(Nodes* head){
	Nodes* temp = head;
	while(temp!=NULL){
		cout<<temp->data<<" ";
		temp = temp->next;
	}
	cout<<endl;
}

void insertion(Nodes*& head, int val){
	Nodes* newNodes = new Nodes();
	newNodes->data = val;
	newNodes->next = NULL;
	
	if(head == NULL){
		head = newNodes;
	}
	else{
		Nodes* temp = head;
		while(temp->next != NULL){
			temp = temp->next;
		}
		temp->next = newNodes;
	}
}

void deletionAtStart(Nodes*& head){
	if(head == NULL){
		cout<<"List is empty. Nothing to delete."<<endl;
		return;
	}
	
	Nodes* temp = head;
	head = head->next;
	
	cout<<"!!! Deleting "<<temp->data<<" !!!"<<endl;
	delete temp;
}

void deletionAtEnd(Nodes*& head){
	if (head == NULL){
		cout<<"List is empty. NOthing to delete."<<endl;
		return;
	}
	
	if(head->next == NULL){
		cout<<"\nDeleting "<<head->data<<endl;
		delete head;
		head = NULL;
		return;
	}
	
	Nodes* temp = head;
	while(temp->next->next != NULL){
		temp = temp->next;
	}
	
	Nodes* del = temp->next;
	cout<<"!!! Deleting "<<del->data<<" !!!"<<endl;
	temp->next = NULL;
	delete del;
}

void deletionAtPosition(Nodes*& head, int pos){
	if(head == NULL){
		cout<<"List is empty. Nothing to delete."<<endl;
		return;
	}
	
	if(pos == 1){
		Nodes* temp = head;
		head = head->next;
		cout<<"!!! Deleting "<<temp->data<<" !!!"<<endl;
		delete temp;
		return;
	}
	
	Nodes* temp = head;
	for(int i=1; temp->next != NULL && i<pos-1; i++){
		temp = temp->next;
	}
	
	if (temp == NULL || temp->next == NULL){
		cout<<"Invalid position. Nothing is to delete."<<endl;
		return;
	}
	
	Nodes* del = temp->next;
	temp->next = del->next;
	cout<<"!!! Deleting "<<del->data<<" !!!"<<endl;
	delete del;
}

int main(){
	Nodes* node = NULL;
	int choice;
	
	insertion(node,10);
	insertion(node,20);
	insertion(node,30);
	insertion(node,40);
	insertion(node,50);
	
	cout<<"****Menu****"<<endl;
	do{
		cout<<"\n1 for deletion from start."<<endl;
		cout<<"2 for deletion from end."<<endl;
		cout<<"3 for deletion from specific position."<<endl;
		cout<<"4 for Exit."<<endl;
		cout<<"\nChoose from the above option: ";
		cin>>choice;
		
		switch(choice){
			case 1:
				cout<<"Original list: "<<endl;
				display(node);
				deletionAtStart(node);
				cout<<"\nAfter deletion: "<<endl;
				display(node);
				break;
		
			case 2:
				cout<<"Original list: "<<endl;
				display(node);
				deletionAtEnd(node);
				cout<<"\nAfter deletion: "<<endl;
				display(node);
				break;
		
			case 3:	
				cout<<"Original list: "<<endl;
				display(node);
				int pos;
				cout<<"Enter the position you want to delete: ";
				cin>>pos;
				deletionAtPosition(node,pos);
				cout<<"\nAfter deletion: "<<endl;
				display(node);
				break;
			
			case 4:
				cout<<"Exiting...."<<endl;
				cout<<"Final list is: ";
				display(node);
				break;
				
			default:
				cout<<"Invalid choice---";		
		}
	}
	while(choice != 4);
	return 0;
}
