#include<iostream>
#include<string>
using namespace std;

class Node{
	public:	
		string title;
		int page;
		float price;
		int edition;
		Node* next;
	
		Node(string t, int pg, float p, int ed){
			title = t;
			page = pg;
			price = p;
			edition = ed;
			next = NULL;
		}
};

class Stack{
		Node* top;
		
	public:
		Stack(){
			top = NULL;
		}
	
	void display(){
		if(top==NULL){
			cout<<"Empty Stack."<<endl;
			return;
		}
		Node* temp = top;
		while(temp!=NULL){
			cout<<"Title: "<<temp->title<<endl;
			cout<<"Price: "<<temp->price<<endl;
			cout<<"Edition: "<<temp->edition<<endl;
			cout<<"No. of pages: "<<temp->page<<endl<<endl;
			temp = temp->next;
		}
	}
	
	void push(string title, int page, float price, int edition){
		Node* newNode = new Node(title,page,price,edition);
		newNode->next = top;
		top = newNode;
		cout<<"Added Successfully."<<endl<<endl;
	}
	
	void pop(){
		if(top==NULL){
			cout<<"Empty Stack."<<endl;
			return;
		}
		cout<<"Deleting "<<top->title<<endl;
		Node* del = top;
		top = top->next;
		delete del;
		cout<<"Deleted Successfully."<<endl<<endl;
	}
	
	void peek(){
		if(top==NULL){
			cout<<"Empty Stack."<<endl;
			return;
		}
		cout<<top->title<<" is the top element."<<endl<<endl;
	}
};


int main(){
	Stack book;
	
	book.push("Harry Potter",200,500.0,2005);
	book.push("Little Women",220,800.0,2020);
	book.push("Mouse",315,760.0,2023);
	book.push("Few Things",440,999.9,1999);
	book.push("Home",110,600.0,2025);
	
	book.peek();
	book.pop();
	book.pop();
	
	book.display();
	return 0;
}
