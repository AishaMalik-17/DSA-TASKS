#include<iostream>
using namespace std;

class Inventory{
	int serialNum;
	int manufactYear;
	int lotNum;
	
	public:
		
		Inventory() {
			serialNum = manufactYear = lotNum = 0;
		}
		Inventory(int sn, int m, int ln){
			serialNum = sn;
			manufactYear = m;
			lotNum = ln;
		}
		
		void setData(int s, int y, int l) {
        serialNum = s;
        manufactYear = y;
        lotNum = l;
    }

    void display(){
        cout<<"Serial Number: "<<serialNum<<endl;
        cout<<"Manufacture Year: "<<manufactYear<<endl;
        cout<<"Lot Number: "<<lotNum<<endl<<endl;
    }
};

class Node {
public:
    Inventory data;
    Node* next;

    Node(Inventory inv){
        data = inv;
        next = NULL;
    }
};

class Stack{
	Node* top;
	
	public:
		Stack(){
			top = NULL;
		}
		
		void push(Inventory inv){
			Node* newNode = new Node(inv);
			newNode->next = top;
			 top = newNode;
			 cout<<"Added Successfully"<<endl<<endl;
		}
		
		void pop(){
			if(top==NULL){
				cout<<"Empty Stack."<<endl;
				return;
			}
			cout<<"Deleting ";
			top->data.display();
			Node* del = top;
			top = top->next;
			delete del;
			cout<<"Deleted Successfully."<<endl<<endl;
		}
		
		void peek(){
			if(top==NULL){
				cout<<"Empty Stack."<<endl;
				return;
			}
			cout<<"Top element."<<endl;
			top->data.display();
		}
		
		void display(){
        if (top == NULL) {
            cout<<"Inventory is empty.\n";
            return;
        }

        cout << "\nRemaining Parts in Inventory:\n";
        Node* temp = top;
        while (temp != NULL) {
            temp->data.display();
            temp = temp->next;
        }
        cout<<endl<<endl; 
    }
    
    ~Stack() {
        while (top != NULL) {
            Node* temp = top;
            top = top->next;
            delete temp;
        }
    }
};


int main(){
	Stack inventoryStack;
    int choice;

    cout << "=== INVENTORY MANAGEMENT SYSTEM ===\n";

    do {
        cout<<"\n1. Add Part to Inventory"<<endl;
        cout<<"2. Take Part from Inventory"<<endl;
        cout<<"3. Display"<<endl;
        cout<<"4. Exit"<<endl<<endl;
        cout<<"Enter your choice: ";
        cin>>choice;

		switch(choice){
        	case 1:{
				
            	int serial, year, lot;
            	cout<<"Enter Serial Number: ";
            	cin>>serial;
            	cout<<"Enter Manufacture Year: ";
            	cin>>year;
            	cout<<"Enter Lot Number: ";
            	cin>>lot;

            	Inventory part;
            	part.setData(serial, year, lot);
            	inventoryStack.push(part);
            	break;
            }
        	case 2:
            	inventoryStack.pop();
            	break;
            	
        	case 3:
            	inventoryStack.display();
            	break;
        
        	case 4:
            	cout<<"Exiting....."<<endl;
            	break;
            	
        	default:
            	cout<<"Invalid choice. Try again.\n";
        }

    } 
	while (choice != 4);

    return 0;
}
